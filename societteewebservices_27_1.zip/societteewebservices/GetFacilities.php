<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$societyId = null;

if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];

//$societyId =8;

$facilities = array();
	 $sql = "SELECT `societyId`, `facilityId`, `facilityName`, `description`, `image`, `deposite`, `availableFlag`, `currentDate`, `dummyField2` 
			FROM `facility` 
			WHERE societyId=$societyId ";
				
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
					$facilities[] = array("facilityId" => $row['facilityId'],
										"facilityName" => $row['facilityName'],
										"description" => $row['description'],
										"image" => $row['image'],
										"deposite" => $row['deposite'],
										"availableFlag" => $row['availableFlag']);
		}
		$response = array("response" => $facilities);
		echo json_encode($response);
	}
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
?>
