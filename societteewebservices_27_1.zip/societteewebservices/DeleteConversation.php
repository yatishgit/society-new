<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$conversationId=null;
$userId=null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$conversationId = $_POST['conversationId'];
	$userId = $_POST['userId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$conversationId = $_GET['conversationId'];
	$userId = $_GET['userId'];
}

//SELECT `conversationId`, `societyId`, `userId`, `createDate`, `date11`, `type`, `imageId`, `description`, `viewFlagManager`, `viewFlagSadmin`, `conversationTitle` FROM `conversation` WHERE 1

$selectConversation="SELECT `conversationId`, `societyId`, `userId`, `createDate`, `type`, `imageId`, `description` 
					FROM `conversation`
					WHERE societyId=$societyId and conversationId=$conversationId and userId=$userId";

$deleteConversation = "DELETE
					   FROM `conversation` 
					   WHERE societyId=$societyId and conversationId=$conversationId and userId=$userId";
				


$selectResult=$conn->query($selectConversation);
					 
	if ($selectResult->num_rows > 0) 
	{
		$imageId=null;
		while($row = $selectResult->fetch_assoc()) 
		{
			$imageId=$row['imageId'];
		}
		
		if($conn->query($deleteConversation) == TRUE)
		{
			$deleteImages = "DELETE FROM `images` WHERE imageId=$imageId";
			if($imageId!="0")
			{
				if($conn->query($deleteImages) == TRUE)
				{
					$response = array("response" => "success");
					echo json_encode($response);	
				}	
				else
				{
					$response = array("response" => "failure");
					echo json_encode($response);
				}
			}
			else
			{
				$response = array("response" => "success");
				echo json_encode($response);
			}			
		}
		else
		{
			$response = array("response" => "failure");
			echo json_encode($response);
		}
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>