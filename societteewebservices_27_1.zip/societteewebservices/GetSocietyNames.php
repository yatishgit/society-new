<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyNames = array();
//SELECT `societyId`, `regiNo`, `societyName`, `managerUsername`, `societyAdd1`, `societyAdd2`, `societyAdd3`, `societyAdd4`, `currentDate`, `valid` FROM `society` WHERE 1
	 $sql = "SELECT `societyId`, `regiNo`, `societyName`, `managerUsername`, `societyAdd1`, `societyAdd2`, `societyAdd3`, `societyAdd4`, `currentDate`
			FROM `society` WHERE 1";
				
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$societyNames[] = array("societyId" => $row['societyId'], 
									"managerUsername" => $row['managerUsername'],
									"regiNo" => $row['regiNo'],
									"societyName" => $row['societyName'],
									"societyAdd1" => $row['societyAdd1'],
									"societyAdd2" => $row['societyAdd2'],
									"societyAdd3" => $row['societyAdd3'],
									"societyAdd4" => $row['societyAdd4'],
									"currentDate" => $row['currentDate']
									);
		}
		
		$response = array("response" => $societyNames);
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
?>
