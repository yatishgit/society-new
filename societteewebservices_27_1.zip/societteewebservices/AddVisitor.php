<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$buildingId = null;
$flatNo = null;
$name = null;
$contactNo = null;
$visitorType =null;
$expectedTime =null;
$date =null;
$checkinTime =null;
$checkoutTime=null;



if($_SERVER['REQUEST_METHOD']=='POST'){
	$societyId = $_POST['societyId'];
	$buildingId = $_POST['buildingId'];
	$flatNo = $_POST['flatNo'];
	$name = $_POST['name'];
	$contactNo = $_POST['contactNo'];
	$visitorType = $_POST['visitorType'];
	$expectedTime = $_POST['expectedTime'];
	$date = $_POST['date'];
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$societyId = $_GET['societyId'];
	$buildingId = $_GET['buildingId'];
	$flatNo = $_GET['flatNo'];
	$name = $_GET['name'];
	$contactNo = $_GET['contactNo'];
	$visitorType = $_GET['visitorType'];
	$expectedTime = $_GET['expectedTime'];
	$date = $_GET['date'];
}
//INSERT INTO `visitor`(`name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, 
//`currentDate`, `checkinTime`, `checkoutTime`, `expectedTime`, `date`) VALUES 
	 $sql = "INSERT INTO `visitor`(`name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, 
			`currentDate`, `expectedTime`, `date`) 
			VALUES 
			('$name',$contactNo,$societyId,$buildingId,'$flatNo','visitorType','date()','$expectedTime','$date')";
			
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>