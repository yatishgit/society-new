<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$pollId = null;
$pollTitle = null;
$creatorId = null;
$contactNo = null;
$creator = null;
$description = null;
$pollDate = null;
$expiryDate = null;
$pollFor = null;
$currentDate = null;
$polloptions = array();

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$creator = $_POST['creator'];
	$pollTitle = $_POST['pollTitle'];
	$creatorId = $_POST['creatorId'];
	$description = $_POST['description'];
	$pollDate = $_POST['pollDate'];
	$expiryDate = $_POST['expiryDate'];
	$pollFor = $_POST['pollFor'];
	$currentDate = $_POST['currentDate'];
	$pollOptions = $_POST['pollOptions'];
	$contactNo = $_POST['contactNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$creator = $_GET['creator'];
	$pollTitle = $_GET['pollTitle'];
	$creatorId = $_GET['creatorId'];
	$description = $_GET['description'];
	$pollDate = $_GET['pollDate'];
	$expiryDate = $_GET['expiryDate'];
	$pollFor = $_GET['pollFor'];
	$currentDate = $_GET['currentDate'];
	$pollOptions = $_GET['pollOptions'];
	$contactNo = $_GET['contactNo'];
}
//$societyId = 8;
$pollId =null;
$insertOptionCount=0;
$count=0;

//INSERT INTO `polling`(`pollId`, `societyId`, `creator`, `description`, `pollDate`, `expiryDate`, `viewFlagManager`, 
//`viewFlagSadmin`, `status`, `pollFor`, `currentDate`, `contactNo`)
$insertPoll = "INSERT INTO `polling`(`societyId`, `creatorId`,`creator`, `pollTitle`, `description`, `pollDate`, `expiryDate`,`viewFlagManager`,`viewFlagSadmin`, `status`, `pollFor`, `currentDate`, `contactNo`) 
				VALUES ($societyId,$creatorId,'$creator','$pollTitle','$description','$pollDate','$expiryDate',0,0,'Open','$pollFor','$currentDate',$contactNo)";


	if ($conn->query($insertPoll) === TRUE) 
	{
		$maxPollId ="SELECT max(`pollId`) as 'pollId' FROM `polling` WHERE societyId = $societyId";
		$res = $conn->query($maxPollId);
		if ($res->num_rows > 0) {
				// fetching poll options from polloptions table for each poll in polling table
				while($r = $res->fetch_assoc()) {
					$pollId=$r['pollId'];
				}
				$order=0;
				echo $pollOptions;
				
				foreach($pollOptions as $optiona)
				{
					$op=$optiona;
					$order=$order+1;
					$insertPollOptions = "INSERT INTO `polloption`(`pollId`, `options`,`orderId`) 
										  VALUES ($pollId,'$op',$order)";
					if ($conn->query($insertPollOptions) === TRUE) 
					{
						$insertOptionCount=$insertOptionCount+1;
					}
				}
		}
		if($count==$insertOptionCount)
		{
			$response = array("response" => "success");
			echo json_encode($response);
		}
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>