<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buildingId = null;
$visitorId=null;;
$societyId =null;
$flatNo=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$visitorId = $_POST['visitorId'];
	$societyId = $_POST['societyId'];
	$flatNo = $_POST['flatNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$visitorId = $_GET['visitorId'];
	$societyId = $_GET['societyId'];
	$flatNo = $_GET['flatNo'];
}
//SELECT `visitorId`, `name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, `currentDate`, `checkinTime`,
// `checkoutTime`, `expectedTime`, `date` FROM `visitor` WHERE 1

$deleteVisitor="DELETE 
				FROM `visitor` 
				WHERE buildingId=$buildingId and visitorId=$visitorId and societyId=$societyId and flatNo='$flatNo'";
				
	if ($conn->query($deleteVisitor) === TRUE) 
	{
		//$sql="SELECT * FROM `visitor` WHERE buildingId=$buildingId and visitorId=$visitorId and societyId=$societyId and flatNo='$flatNo'";
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>