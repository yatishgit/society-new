<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	$album = array();
	$images = array();
	if($_SERVER['REQUEST_METHOD']=='POST')
		$societyId=$_POST['societyId'];
	if($_SERVER['REQUEST_METHOD']=='GET')
		$societyId=$_GET['societyId'];
	//$societyId = 8;

	//fetching albums
	$getAlbums = "SELECT  Distinct(`albumId`), `albumTitle`, `addedDate`, `description` FROM `album` WHERE `societyId`=$societyId";	
	$result = $conn->query($getAlbums);
	if ($result->num_rows > 0) {
	// output data of each row
		while($row = $result->fetch_assoc()) {
			$albumId=$row['albumId'];
			//echo $albumId;
			$getImages="SELECT `imageId`, `albumId`, `societyId`, `image` FROM `albumimages` WHERE `albumId`=$albumId";
			$image_result = $conn->query($getImages);
			if ($image_result->num_rows > 0) {
			// output data of each row
				$images = null;
				while($image_row = $image_result->fetch_assoc()) {
					$images[] = array("imageId" => $image_row['imageId'],
									"albumId" => $image_row['albumId'],
									"societyId" => $image_row['societyId'],
									"image" => $image_row['image']);
				}
			}
			
			$album[] = array("albumId" => $row['albumId'],
							 "albumTitle" => $row['albumTitle'],
							 "addedDate" => $row['addedDate'],
							 "description" => $row['description'],
							 "images" => $images);
									
		}
		$response = array("response" => $album);
		echo json_encode($response);		
	}//end if
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

			
?>