<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$flatNo=$_POST['flatNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$flatNo=$_GET['flatNo'];
}

$expetedVistitors = array();

$sql = "SELECT `visitorId`, `name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, `currentDate`, `checkinTime`, `checkoutTime`, 
		`expectedTime`, `date` 
		FROM `visitor` 
		WHERE buildingId='$buildingId' and flatNo='$flatNo'";
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$expetedVistitors[]=array("visitorId" => $row['visitorId'],
							 "name" => $row['name'],
							 "contactNo" => $row['contactNo'],
							 "societyId" =>$row['societyId'],
							 "buildingId" =>$row['buildingId'],
							 "flatNo" => $row['flatNo'],
							 "visitorType" => $row['visitorType'],
							 "checkinTime" => $row['checkinTime'],
							 "checkoutTime" => $row['checkoutTime'],
							 "expectedTime" => $row['expectedTime'],
							 "date" => $row['date']);
		}
		$response = array("response" => $expetedVistitors);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}
?>