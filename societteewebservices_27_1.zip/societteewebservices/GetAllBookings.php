<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buildingId = null;
$userId=null;;
$societyId =null;
$flatNo=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$userId = $_POST['userId'];
	$societyId = $_POST['societyId'];
	$flatNo = $_POST['flatNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$userId = $_GET['userId'];
	$societyId = $_GET['societyId'];
	$flatNo = $_GET['flatNo'];
}

$getAllBookings="SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, `depositedDate`,
				`rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`, `chequeNo`, `currentDate`, 
				`status`, `societyId`, `viewFlagManager`, `viewFlagSadmin` 
				FROM `booking` 
				WHERE  societyId=$societyId and buildingId=$buildingId and flatNo='$flatNo' and userId=$userId";
			
$result=$conn->query($getAllBookings);
$bookings=array();
if($result->num_rows > 0) 
{
	
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		$facilityName=null;
		$description=null;
		$image=null;
		$userName=null;
		$facilityId = $row['facilityId'];
		$userId = $row['userId'];
		
		$getFacility = "SELECT `societyId`, `facilityId`, `facilityName`, `description`, `image`, `deposite`, `availableFlag`, `currentDate`, 
						`dummyField2` 
						FROM `facility` 
						WHERE facilityId=$facilityId";
		$res=$conn->query($getFacility);
		if($res->num_rows > 0){
			while($r = $res->fetch_assoc())
			{
				$facilityName=$r['facilityName'];
				$description=$r['description'];
				$image=$r['image'];
			}
		}
		
		$getUser = "SELECT `userId`, `image`, `name`, `userType`, `contactNo`, `emailId`, `expiryDate`, `approvalStatus`, `pollingAllowed`, 
					`societyId`, `buildingId`, `flatNo`, `currentDate`, `viewFlagManager`, `viewFlagSadmin`, `username`, `password`, `valid` 
					FROM `user` WHERE userId=$userId";
		$res1=$conn->query($getUser);
		if($res1->num_rows > 0){
			while($r1 = $res1->fetch_assoc())
			{
				$userName=$r1['name'];
				
			}
		}
		
		$bookings[] = array("bookingId" => $row['bookingId'],
								"bookingDate" => $row['bookingDate'],
								"userId" => $row['userId'],
								"facilityId" => $row['facilityId'],
								"fromDate" => $row['fromDate'],
								"toDate" => $row['toDate'],
								"buildingId" => $row['buildingId'],
								"flatNo" => $row['flatNo'],
								"amountDeposited" => $row['amountDeposited'],
								"depositedDate" => $row['depositedDate'],
								"rdescription" => $row['rdescription'],
								"rpaymentMode" => $row['rpaymentMode'],
								"rchequeNo" => $row['rchequeNo'],
								"amountRefunded" => $row['amountRefunded'],
								"refundedDate" => $row['refundedDate'],
								"description" => $row['description'],
								"paymentMode" => $row['paymentMode'],
								"chequeNo" => $row['chequeNo'],
								"status" => $row['status'],
								"societyId" => $row['societyId'],
								"facilityName" => $facilityName,
								"facility_description" => $description,
								"image" => $image,
								"userName" => $userName);
	}
	$response = array("response" => $bookings);
	echo json_encode($response);
}
else
{
	$response = array("response" => "failure");
	echo json_encode($response);
}	

?>