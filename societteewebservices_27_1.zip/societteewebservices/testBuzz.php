<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$getPolloptions = "SELECT `pollId`, `optionId`, `options`, `dummyField1` 
				   FROM `polloption` 
				   WHERE pollId = 20"; 
$pollOptionsResult = $conn->query($getPolloptions);
if ($pollOptionsResult->num_rows > 0) {
				// fetching poll options from polloptions table for each poll in polling table
				while($options = $pollOptionsResult->fetch_assoc()) {
					
					echo 'options :'.$options['options'];
				}
}

?>
