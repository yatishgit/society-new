<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$userDetails = array();

$userId = null;
$societyId = null;
$issueName = null;
$buildingId = null;
$category = null;
$description = null;
$issueDate = null;
$image = null;
$type = null;
$issueId = null;

if($_SERVER['REQUEST_METHOD']=='POST'){
	$userId = $_POST['userId'];
	$issueId = $_POST['issueId'];
	$societyId = $_POST['societyId'];
	$issueName = $_POST['issueName'];
	$buildingId = $_POST['buildingId'];
	$description = $_POST['description'];
	$image = $_POST['image'];
	$type = $_POST['type'];
		$currentDate = date('Y-m-d H:i:s');
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$userId = $_GET['userId'];
	$issueId = $_GET['issueId'];
	$societyId = $_GET['societyId'];
	$issueName = $_GET['issueName'];
	$buildingId = $_GET['buildingId'];
	$description = $_GET['description'];
	$image = $_GET['image'];
	$type = $_GET['type'];
	$currentDate = date('Y-m-d H:i:s');
}

$maxid=$issueId;
	
$imageId=$maxId.".jpg";
$path="personal_issue_images/".$imageId;
	 
	 $sql = "UPDATE `helpdeskpersonal` SET `issueName`='$issueName',`category`=[value-5],`description`='$description',
			`image`='$path',`type`='$type'
			WHERE societyId=$societyId and issueId=$issueId";
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		if ($result) {
			file_put_contents($path,base64_decode($image));
		}
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>