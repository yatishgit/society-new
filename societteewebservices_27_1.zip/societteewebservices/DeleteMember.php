<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buildingId = null;
$userId=null;
$userType=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$userId = $_POST['userId'];
	$userType = $_POST['userType'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$userId = $_GET['userId'];
	$userType = $_GET['userType'];
}


$deleteMember="DELETE 
				FROM `user` 
				WHERE userId=$userId and buildingId=$buildingId and userType='$userType'";
				
	if ($conn->query($deleteMember) === TRUE) 
	{
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>