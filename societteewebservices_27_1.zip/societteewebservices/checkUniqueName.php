<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$userName = null;

if($_SERVER['REQUEST_METHOD']=='POST'){
	$userName = $_POST['userName'];
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$userName = $_POST['userName'];
}

$maxid=null;
	$getmaxId="SELECT `userId`, `image`, `name`, `userType`, `contactNo`, `emailId`, `expiryDate`, `approvalStatus`, `pollingAllowed`, `societyId`, `buildingId`, `flatNo`, `currentDate`, `viewFlagManager`, `viewFlagSadmin`, `username`, `password`, `valid` 
	FROM `user` WHERE username='$userName'";
	$result1 = $conn->query($getmaxId);
	if($result1->num_rows > 0){
		while($r=$result1->fetch_assoc()){
			$response = array("response" => "Failure");
		echo json_encode($response);
		}
	}
	else {
		$response = array("response" => "success");
		echo json_encode($response);
	}
	$conn->close();

?>