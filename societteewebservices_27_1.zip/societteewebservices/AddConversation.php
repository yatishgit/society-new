<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$userId = $_POST['userId'];
	$createDate = $_POST['createDate'];
	$type = $_POST['type'];
	$description = $_POST['description'];
	$images = $_POST['image'];
}

if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$userId = $_POST['userId'];
	$createDate = $_POST['createDate'];
	$type = $_POST['type'];
	$description = $_POST['description'];
	$images = $_POST['image'];
}



$sql = "INSERT INTO `conversation`(`societyId`, `userId`, `createDate`, `type`, `imageId`, `description`) 
		VALUES ($societyId,$createDate',$$type,imageId,'$description')";
		
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>