<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$buildingId = null;
$flatNo = null;
$name = null;
$contactNo = null;
$designation = null;
$idProof = null;



if($_SERVER['REQUEST_METHOD']=='POST'){
	$societyId = $_POST['societyId'];
	$buildingId = $_POST['buildingId'];
	$flatNo = $_POST['flatNo'];
	$name = $_POST['name'];
	$contactNo = $_POST['contactNo'];
	$designation = $_POST['designation'];
	$idProof = $_POST['idProof'];
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$societyId = $_GET['societyId'];
	$buildingId = $_GET['buildingId'];
	$flatNo = $_GET['flatNo'];
	$name = $_GET['name'];
	$contactNo = $_GET['contactNo'];
	$designation = $_GET['designation'];
	$idProof = $_GET['idProof'];
}
	 $sql = "INSERT INTO `staff`(`name`, `designation`, `contactNo`, `idProof`, `societyId`, `buildingId`, `flatNo`, `currentDate`) 
			VALUES 
			('$name','$designation',$contactNo,'$idProof',$societyId,$buildingId,'$flatNo','date()')";
			
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>