<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$issueId=null;
$userId=null;
$buildingId=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$issueId = $_POST['issueId'];
	$userId = $_POST['userId'];
	$buildingId = $_POST['buildingId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$issueId = $_GET['issueId'];
	$userId = $_GET['userId'];
	$buildingId = $_GET['buildingId'];
}

//$societyId = 8;SELECT `conversationId`, `societyId`, `userId`, `createDate`, `type`, `imageId`, `description`, `viewFlag` FROM `conversation` WHERE 1

$selectIssue="SELECT `image`
				FROM `helpdeskpersonal` 
				WHERE societyId=$societyId and issueId=$issueId and userId=$userId and buildingId=$buildingId";

$deleteHelpdesk = "DELETE
					   FROM `helpdeskpersonal`
					   WHERE societyId=$societyId and issueId=$issueId and userId=$userId and buildingId=$buildingId";
				


$selectResult=$conn->query($selectIssue);
					 
	if ($selectResult->num_rows > 0) 
	{
		$image=null;
		while($row = $selectResult->fetch_assoc()) 
		{
			$image=$row['image'];
			//add code to delete image from folder
		}
		
		if($conn->query($deleteHelpdesk) == TRUE)
		{
			$response = array("response" => "success");
			echo json_encode($response);	
		}
		else
		{
			$response = array("response" => "failure");
			echo json_encode($response);
		}
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>