<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;


if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];
//$societyId = 8;

$buildings = array();

$sql = "SELECT `buildingId`, `buildingName`, `description`, `societyId`, `dummyfield`, `currentDate` 
		FROM `building` 
		WHERE societyId=$societyId";
		
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$buildings[]=array("buildingId" =>$row['buildingId'],
							   "buildingName" =>$row['buildingName'],
							   "description" => $row['description'],
							   "societyId" => $row['societyId']);
		}
		$response = array("response" => $buildings);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>