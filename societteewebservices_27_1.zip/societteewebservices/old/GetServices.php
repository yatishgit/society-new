<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$category = array();
	 $sql = "SELECT `categoryId`, `vendorName`, `vendorId`, `vendorContact1`, `vendorContact2`, `vendorAdd1`, `vendorAdd2`, 
			`vendorAdd3`, `vendorAdd4`, `company`, `idProof`, `description`, `currentDate`, `dummyfield 2` 
			FROM `buzz` 
			WHERE 1";
				
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			
			$category_id = $row['categoryId'];
			
			$categorysql = "SELECT `categoryId`, `categoryName`, `cateDescription`, `cateImage` 
							FROM `vendorcategory` 
							WHERE `categoryId`=$category_id";
			$result1 = $conn->query($categorysql);

			if ($result1->num_rows > 0) {
				// output data of each row
				while($row1 = $result1->fetch_assoc()) {
					$category[] = array("categoryId" => $row1['categoryId'],
										"categoryName" => $row1['categoryName'],
										"cateDescription" => $row1['cateDescription'],
										"cateImage" => $row1['cateImage']);
				}
			}
		}
		echo json_encode($category);
	} 
	else {
		echo "Failure";
	}
?>
