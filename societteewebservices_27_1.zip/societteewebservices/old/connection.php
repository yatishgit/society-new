
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
    if($mysqli_connect_error())
        die('Connect Error');

?>