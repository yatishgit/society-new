<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];
//$societyId = 8;

$conversations = array();
$images =array();
//SELECT `conversationId`, `societyId`, `userId`, `createDate`, `date11`, `type`, `imageId`, `description`, `viewFlagManager`, 
//`viewFlagSadmin`, `conversationTitle` FROM `conversation` WHERE 1

$sql = "SELECT `conversationId`, `societyId`, `userId`, `createDate`, `date11`, `type`, `imageId`, `description`, `conversationTitle`
		FROM `conversation` 
		WHERE societyId=$societyId";
$result = $conn->query($sql);

$userName=null;
$profileImage=null;
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$images = null;
			$conversationId=$row['conversationId'];
			$userId=$row['userId'];
			$getUserDetails="SELECT `userId`, `image`, `name`FROM `user` WHERE userId=$userId";
			$userResult=$conn->query($getUserDetails);
			if($userResult->num_rows > 0)
			{
				while($userrow = $userResult->fetch_assoc()){
					$userName=$userrow['name'];
					$profileImage=$userrow['image'];
				}
			}
			
			$imageId=$row['imageId'];
			
				$imageSql="SELECT `imageId`, `conversationId`, `societyId`, `image` 
						   FROM `conversationimages` 
						   WHERE conversationId = $conversationId";
				$imageresult = $conn->query($imageSql);
				if ($imageresult->num_rows > 0) {
					// output data of each row
					while($imagerow = $imageresult->fetch_assoc()) {
						$images[] =array("imageId" => $imagerow['imageId'],
										 "image" => $imagerow['image']);
					}
				}
				else
				{
					$images[] = null;
				}
				
				$conversations[]=array("conversationId" => $row['conversationId'],
								 "societyId" => $row['societyId'],
								 "userId" => $row['userId'],
								 "userName" => $userName,
								 "profileImage" => $profileImage,
								 "createDate" => $row['createDate'],
								 "date11" => $row['date11'],
								 "type" =>$row['type'],
								 "albumId" =>$row['imageId'],
								 "images" => $images,
								 "description" => $row['description'],
								 "conversationTitle" => $row['conversationTitle']);
			
		}
		$response = array("response" => $conversations);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>