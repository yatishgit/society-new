<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$userDetails = array();

$userId = null;
$societyId = null;
$issueName = null;
$buildingId = null;
$category = null;
$description = null;
$issueDate = null;
$image = null;
$type = null;

if($_SERVER['REQUEST_METHOD']=='POST'){
	$userId = $_POST['userId'];
	$societyId = $_POST['societyId'];
	$issueName = $_POST['issueName'];
	$buildingId = $_POST['buildingId'];
	$category = $_POST['category'];
	$description = $_POST['description'];
	$image = $_POST['image'];
	$type = $_POST['type'];
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$userId = $_GET['userId'];
	$societyId = $_GET['societyId'];
	$issueName = $_GET['issueName'];
	$buildingId = $_GET['buildingId'];
	$category = $_GET['category'];
	$description = $_GET['description'];
	$image = $_GET['image'];
	$type = $_GET['type'];
}

$maxid=null;
	$getmaxId="SELECT max(issueId) as 'max' FROM `helpdeskpersonal`";
	$result1 = $conn->query($getmaxId);
	if($result1->num_rows > 0){
		while($r=$result1->fetch_assoc()){
			$maxId=$r['max'];
			$maxId=$maxId+1;
		}
	}
$imageId=$maxId.".jpg";
$path="personal_issue_images/".$imageId;
	 
	 $sql = "INSERT INTO `helpdeskpersonal`(`societyId`, `issueName`, `buildingId`, `category`, `userId`, `description`, `issueDate`, 
			`resolvedStatus`, `resolvedDate`, `status`, `image`, `issueBy`, `currentDate`, `viewFlagManager`, `viewFlagSadmin`, `type`) 
			VALUES 
			($societyId,'$issueName',$buildingId,'$category',$userId,'$description','$issueDate',0,null,0,'$path',null,'date()',0,0,'$type')";
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		if ($result) {
			file_put_contents($path,base64_decode($image));
		}
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>