<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$pollId=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$pollId = $_POST['pollId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$pollId = $_GET['pollId'];
}

//$societyId = 8;SELECT `conversationId`, `societyId`, `userId`, `createDate`, `type`, `imageId`, `description`, `viewFlag` FROM `conversation` WHERE 1

$deletePolling="DELETE
			FROM `polling` 
			WHERE societyId=$societyId and pollId=$pollId";

$deletepolloption = "DELETE FROM `polloption` WHERE pollId=$pollId";

$deleteResponse = "DELETE FROM `pollingresponse` WHERE pollId=$pollId";
				
	if ($conn->query($deletePolling) === TRUE) 
	{
		if($conn->query($deletepolloption) === TRUE)
		{
			if($conn->query($deleteResponse) === TRUE)
			{
				$response = array("response" => "success");
				echo json_encode($response);
			}
			else
			{
				$response = array("response" => "failure");
				echo json_encode($response);
			}
		}
		else
		{
			$response = array("response" => "failure");
			echo json_encode($response);
		}
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>