<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

	$userId = null;
	$oldpassword = null;
	$newpassword = null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$userId = $_POST['userId'];
	$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$userId = $_GET['userId'];
	$oldpassword = $_GET['oldpassword'];
	$newpassword = $_GET['newpassword'];
}
$checkPassword = "SELECT `userId`,`password` FROM `user` WHERE userId ='$userId' and password='$oldpassword'";
$checkResult= $conn->query($checkPassword);

if($checkResult->num_rows > 0)
{
	$updatePassword = "UPDATE `user` SET `password`='$newpassword' WHERE userId = $userId";
	if ($conn->query($updatePassword) === TRUE) 
	{
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}
}
else
{
		$response = array("response" => "password error");
		echo json_encode($response);
}
?>