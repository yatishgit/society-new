<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buildingId = null;
$userId=null;;
$societyId =null;
$flatNo=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$userId = $_POST['userId'];
	$societyId = $_POST['societyId'];
	$flatNo = $_POST['flatNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$userId = $_GET['userId'];
	$societyId = $_GET['societyId'];
	$flatNo = $_GET['flatNo'];
}

$selectTransactions="SELECT `transactionId`, `userId`, `societyId`, `buildingId`, `flatNo`, `paymentType`, `description`, `dueAmount`, `raisedDate`, 
					`dueDate`, `catagory`, `paymentStatus`, `paymentDate`, `paidAmount`, `paymentMode`, `chequeNo`, `refId`, `netBalance`, `due`, 
					`viewFlagManager`, `viewFlagSadmin` 
					FROM `payment` 
					WHERE societyId=$societyId and buildingId=$buildingId and flatNo='$flatNo' and userId=$userId";
			
$result=$conn->query($selectTransactions);
$transactions=array();
if($result->num_rows > 0) 
{
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		$transactions[] = array("transactionId" => $row['transactionId'],
								"paymentType" => $row['paymentType'],
								"description" => $row['description'],
								"dueAmount" => $row['dueAmount'],
								"raisedDate" => $row['raisedDate'],
								"dueDate" => $row['dueDate'],
								"catagory" => $row['catagory'],
								"paymentStatus" => $row['paymentStatus'],
								"paymentDate" => $row['paymentDate'],
								"paidAmount" => $row['paidAmount'],
								"paymentMode" => $row['paymentMode'],
								"chequeNo" => $row['chequeNo'],
								"refId" => $row['refId'],
								"netBalance" => $row['netBalance'],
								"due" => $row['due'],
								"userId" => $row['userId']);
	}
	$response = array("response" => $transactions);
	echo json_encode($response);
}
else
{
	$response = array("response" => "failure");
	echo json_encode($response);
}	

?>