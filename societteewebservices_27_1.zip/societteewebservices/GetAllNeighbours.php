<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$buildingId = null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$buildingId=$_POST['buildingId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$buildingId=$_GET['buildingId'];
}
//$societyId = 8;

$neighbours = array();

$sql = "SELECT `userId`, `name`, `emailId`, `image`, `societyId`, `buildingId`, `contactNo`, `userType`, `flatNo`
		FROM `user` 
		WHERE societyId=$societyId and buildingId=$buildingId";
		
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$neighbours[]=array("userId" => $row['userId'],
								"name" => $row['name'],
								"emailId" => $row['emailId'],
								"image" => $row['image'],
								"contactNo" => $row['contactNo'],
								"userType" => $row['userType'],
								"flatNo" => $row['flatNo'],
								"buildingId" =>$row['buildingId'],
								"societyId" => $row['societyId']);
		}
		$response = array("response" => $neighbours);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>