<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if($_SERVER['REQUEST_METHOD']=='POST'){
 
 $societyId = $_POST['societyId'];
 $userId = $_POST['userId'];
 $title = $_POST['title'];
 $desc = $_POST['description']; 
 $count = $_POST['count'];
 $date = date('YYYY-mm-dd');
 $conversationId=null;

 
 $insertConversation="INSERT INTO `conversation`(`societyId`, `userId`, `date11`, `type`, `imageId`, `description`,`conversationTitle`) 
						VALUES 
						($societyId,$userId,$date,'0',0,'$desc','$title')";
	$result = $conn->query($insertConversation);
	if ($result) {
		$maxConversationId = "SELECT max(conversationId) as 'conversationId' FROM `conversation`";
			$ConversationIdResult = $conn->query($maxConversationId);
				if ($ConversationIdResult->num_rows > 0) {
					while($i = $ConversationIdResult->fetch_assoc()) {
						 $conversationId = $i['conversationId'];
					}
				}
		if($count>0){
			for($i=0;$i<$count;$i++){
				$imageName = "image".$i;
				$image = $_POST[$imageName];
				$imageId = null;
				$imagepath = "conversation_images/";
				$path=null;
				$maxImageId = "SELECT max(imageId) as 'imageId' FROM `conversationimages`";
				$imageIdResult = $conn->query($maxImageId);
					if ($imageIdResult->num_rows > 0) {
						while($imagerow = $imageIdResult->fetch_assoc()) {
							$imageId = $imagerow['imageId'];
							$imageId = $imageId+1;
							$path = $imagepath.$imageId.".jpg";
						
							$insertConversationImages="INSERT INTO `conversationimages`(`conversationId`, `societyId`, `image`) 
											VALUES ($conversationId,$societyId,'$path')";
							$result1 = $conn->query($insertConversationImages);

							if ($result1) {
								//echo "inserted";
								file_put_contents($path,base64_decode($image));
							}
						}
					}
			}
		}
	}
	$response = array("response" => "success");
		echo json_encode($response);
 }
 else
 {
	$response = array("response" => "failure");
		echo json_encode($response);
 }
 
?>