<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$bookingId = null;
$userId=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$bookingId=$_POST['bookingId'];
	$userId = $_POST['userId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$bookingId=$_GET['bookingId'];
	$userId = $_GET['userId'];
}

//SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, 
//`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`,
// `chequeNo`, `currentDate`, `status`, `societyId` FROM `booking` WHERE 1

$deleteBooking="DELETE
				FROM `booking` 
				WHERE bookingId=$bookingId and userId=$userId";
				
	if ($conn->query($deleteBooking) === TRUE) 
	{
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>