<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	$pollId=null;
	$userId = null;
	$optionId = null;
	$response = null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$pollId=$_POST['pollId'];
	$userId = $_POST['userId'];
	$optionId = $_POST['optionId'];
	$response = $_POST['response'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$pollId=$_GET['pollId'];
	$userId = $_GET['userId'];
	$optionId = $_GET['optionId'];
	$response = $_GET['response'];
}

$pollresult =null;

$checkPoll = "SELECT `pollId`, `userId`, `responseId`, `response` ,`optionId`
				FROM `pollingresponse` 
				WHERE userId = $userId and pollId = $pollId";
$result = $conn->query($checkPoll);
		if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$optionId=$row['optionId'];
					$response=$row['response'];
				}
				$pollresult = array("response_Status" => "Answered",
									"response" => $response,
									"optionId" => $optionId);
				echo json_encode($pollresult);
		}
		else{
			$insertPollAnswer = "INSERT INTO `pollingresponse`(`pollId`, `userId`, `response`, `optionId`)
								VALUES ($pollId,$userId,'$response','$optionId')";

				if ($conn->query($insertPollAnswer) === TRUE) 
				{
					$response = array("response" => "success");
					echo json_encode($response);
				}
				else
				{
					$response = array("response" => "failure");
					echo json_encode($response);
				}
		}
?>