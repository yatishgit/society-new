<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$buildingId = null;
$parkingSlot = null;
$flatNo = null;
$vehicleNo = null;




if($_SERVER['REQUEST_METHOD']=='POST'){
	$societyId = $_POST['societyId'];
	$buildingId = $_POST['buildingId'];
	$parkingSlot = $_POST['parkingSlot'];
	$flatNo = $_POST['flatNo'];
	$vehicleNo = $_POST['vehicleNo'];

}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$societyId = $_GET['societyId'];
	$buildingId = $_GET['buildingId'];
	$parkingSlot = $_GET['parkingSlot'];
	$flatNo = $_GET['flatNo'];
	$vehicleNo = $_GET['vehicleNo'];

}
	 $sql = "DELETE 
			FROM `parking` 
			WHERE societyId=$societyId and buildingId=$buildingId and parkingSlot='$parkingSlot' and flatNo='$flatNo' and vehicleNo='$vehicleNo'";
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>