	<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buzz = array();
$buzz_details = array();

if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];

//$societyId = 8;

$category_id=null;
	//fetching distinct categories from buzz
	 $sql = "SELECT `sbId`, `buzzId`, `societyId`, `categoryId`, `currentDate` FROM `societybuzz` WHERE societyId=$societyId";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$categoryId = $row['categoryId'];
			//echo $category_id;
			//fetching vendor details
			$categorysql = "SELECT `categoryId`, `vendorName`,`buzzId`, `vendorContact1`, `vendorContact2`, `vendorAdd1`, `vendorAdd2`, 
							`vendorAdd3`, `vendorAdd4`, `company`, `idProof`, `description`, `currentDate`, `buzzTitle` 
							FROM `buzz` 
							WHERE categoryId=$categoryId";
							
			$result1 = $conn->query($categorysql);
			
			if ($result1->num_rows > 0) {
				// output data of each row
				$buzz = null;
				while($row1 = $result1->fetch_assoc()) {
					
					$buzz[] = array("categoryId" => $row1['categoryId'],
									"vendorName" => $row1['vendorName'],
									"buzzId" => $row1['buzzId'],
									"vendorContact1" => $row1['vendorContact1'],
									"vendorContact2" => $row1['vendorContact2'],
									"vendorAdd1" => $row1['vendorAdd1'],
									"vendorAdd2" => $row1['vendorAdd2'],
									"vendorAdd3" => $row1['vendorAdd3'],
									"vendorAdd4" => $row1['vendorAdd4'],
									"company" => $row1['company'],
									"idProof" => $row1['idProof'],
									"description" => $row1['description'],
									"currentDate" => $row1['currentDate'],
									"buzzTitle" => $row1['buzzTitle']);
				}
			}
					//SELECT `categoryId`, `categoryName`, `image`, `description`, `currentDate` FROM `category` WHERE 1
					$getcategory = "SELECT `categoryId`, `categoryName`, `image`, `description`, `currentDate` FROM `category` WHERE `categoryId`=$categoryId";		
					$result11 = $conn->query($getcategory);
					
					if ($result11->num_rows > 0) {
						// output data of each row
						while($row = $result11->fetch_assoc()) {
							$buzz_details[] = array("category_id" => $row['categoryId'],
													"categoryName" => $row['categoryName'],
													"description" => $row['description'],
													"image" => $row['image'],
													"currentDate" => $row['currentDate'],
													"vendors" => $buzz);
						}	
					}		
				
				
		}			
				$response = array("response" => $buzz_details);
				echo json_encode($response);		
	}//end if		
			else 
			{
				$response = array("response" => "failure");
				echo json_encode($response);
			}
?>
