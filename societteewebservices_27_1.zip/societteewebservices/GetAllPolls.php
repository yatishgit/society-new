<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$pollId=null;


if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];
//$societyId = 8;

$polls = array();
$pollOptions = array();
$pollOptionResponse =array();

//SELECT `pollId`, `societyId`, `creatorId`, `creator`, `pollTitle`, `description`, `pollDate`, `expiryDate`, `viewFlagManager`, `viewFlagSadmin`, `status`, `pollFor`, `currentDate`, `contactNo` FROM `polling` WHERE 1

$getPollssql = "SELECT `pollId`, `societyId`, `creatorId`, `creator`, `pollTitle`, `description`, `pollDate`, `expiryDate`, `status`, `pollFor`, `currentDate`,`contactNo`
		FROM `polling` 
		WHERE societyId = $societyId";
		
$pollsresult = $conn->query($getPollssql);
	if ($pollsresult->num_rows > 0) {
		// fetching all polls from the polling table
		while($row = $pollsresult->fetch_assoc()) {
		
			$pollOptions = null;
			$pollOptionResponse=null;
			//setting pollId value for passing it to getPolloptions query
			$pollId=$row['pollId'];
			//echo'poll id: '.$row['pollId'];
			
			$getPolloptions = "SELECT `pollId`, `optionId`, `options`, `dummyField1` 
				   FROM `polloption` 
				   WHERE pollId = $pollId"; 
			$pollOptionsResult = $conn->query($getPolloptions);
		
			if ($pollOptionsResult->num_rows > 0) {
				// fetching poll options from polloptions table for each poll in polling table
				while($options = $pollOptionsResult->fetch_assoc()) {
					
					//echo 'options :'.$options['options'];
					//setting responce value for passing it to getResponse query
					$response = $options['optionId'];
					$option = $options['options'];
					
					//SELECT `pollId`, `userId`, `flatId`, `responseId`, `response`, `optionId` FROM `pollingresponse` WHERE 1/
					
					/*$getResponse = "SELECT  count(`optionId`) as response_count
									FROM `pollingresponse` 
									WHERE optionId = $response and pollId=$pollId";*/
					$getResponse = "SELECT `pollId`, `userId`, `flatId`, `responseId`, `response`, `optionId`
									FROM `pollingresponse` 
									WHERE optionId = $response and pollId=$pollId";
					$pollOptionsResponseResult = $conn->query($getResponse);
		
					if ($pollOptionsResponseResult->num_rows > 0) {
						// fetching poll responses for each option
						
						while($optionResponse = $pollOptionsResponseResult->fetch_assoc()) {
							/*$pollOptionResponse[] = array("optionId" => $response,
														  "option" => $option,
														  "option_count" => $optionResponse['response_count']);*/
							//echo $optionResponse['response_count'];
							
							$pollOptionResponse[] = array("pollId" => $optionResponse['pollId'],
														  "userId" => $optionResponse['userId'],
														  "flatId" => $optionResponse['flatId'],
														  "responseId" => $optionResponse['responseId'],
														  "response" => $optionResponse['response'],
														  "optionId" => $optionResponse['optionId'],);
						}
					}
					//$pollOptions[] = $options['options'];
				}
			}
			//SELECT `pollId`, `societyId`, `creatorId`, `creator`, `pollTitle`, `description`, `pollDate`, `expiryDate`, `viewFlagManager`, `viewFlagSadmin`, 
			//`status`, `pollFor`, `currentDate`, `contactNo` FROM `polling` WHERE 1
			$polls[]=array("pollId" => $row['pollId'],
							"societyId" => $row['societyId'],
							"creatorId" => $row['creatorId'],
							 "creator" => $row['creator'],
							 "pollTitle" => $row['pollTitle'],
							 "description" => $row['description'],
							 "pollDate" =>$row['pollDate'],
							 "expiryDate" =>$row['expiryDate'],
							 "status" => $row['status'],
							 "pollFor" => $row['pollFor'],
							 "currentDate" => $row['currentDate'],
							 "contactNo" => $row['contactNo'],
							 "pollOptionResponse" => $pollOptionResponse,
							 );		
			$pollOptionResponse=null;
		}
		$response = array("response" => $polls);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "Failure");
		echo json_encode($response);
	}

?>