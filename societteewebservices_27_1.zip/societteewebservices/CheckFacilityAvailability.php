<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$facilityId = null;
$fromDate = null;
$toDate = null;
$fromTime = null;
$toTime = null;
$buildingId = null;
$flatNo = null;
$societyId = null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$facilityId = $_POST['facilityId'];
	$fromDate = $_POST['fromDate'];
	$toDate = $_POST['toDate'];
	$fromTime = $_POST['fromTime'];
	$toTime = $_POST['toTime'];
	$buildingId = $_POST['buildingId'];
	$flatNo = $_POST['flatNo'];
	$societyId = $_POST['societyId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$facilityId = $_GET['facilityId'];
	$fromDate = $_GET['fromDate'];
	$toDate = $_GET['toDate'];
	$fromTime = $_GET['fromTime'];
	$toTime = $_GET['toTime'];
	$buildingId = $_GET['buildingId'];
	$flatNo = $_GET['flatNo'];
	$societyId = $_GET['societyId'];
}
$d=date('Y-m-d H:i:s');
$fromDate=$fromDate." ".$fromTime;
$toDate = $toDate." ".$toTime;

$CheckAvailability = "SELECT * FROM `booking` WHERE fromDate>='$fromDate' and toDate<='$toDate' and facilityId=$facilityId and societyId=$societyId";
echo $CheckAvailability;
$result=$conn->query($CheckAvailability);

	if ($result->num_rows > 0)		
	{
		$response = array("response" => "not available");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "available");
		echo json_encode($response);
	}

?>