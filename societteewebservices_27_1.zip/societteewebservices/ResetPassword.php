
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//ramdom password generator script
function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

function sendMail($too,$password,$userName){
$to  = $too;
// subject
$subject = 'Society Application Password Reset';

// message
$message = '
<html>
<head>
  <title>Password Reset</title>
</head>
<body>
  <p>Below is is your changed password</p>
  <table>
    <tr>
      <td>User Name</td><td>'.$userName.'</td>
    </tr>
	<tr>
      <td>Password</td><td>'.$password.'</td>
    </tr>
  </table>
   <p>Use the changed password to login to society app.</p>
 

</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= 'To:'.$to. "\r\n";
$headers .= 'From: Society App <birthday@example.com>' . "\r\n";
$headers .= 'Cc: birthdayarchive@example.com' . "\r\n";
$headers .= 'Bcc: birthdaycheck@example.com' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);
}
if($_SERVER['REQUEST_METHOD']=='POST')
{
	$email_id = $_POST['email_id'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$email_id = $_GET['email_id'];
}
	
	$sql = "SELECT `userId`, `name`, `emailId`, `image`, `societyId`, `buildingId`, `contactNo`, `userType`, `flatNo`, `approvalStatus`, `expiryDate`, 
			`pollingAllowed`, `userName`, `password`, `currentDate`, `viewFlag` 
			FROM `user` 
			WHERE emailId='$email_id'";
				
	$result = $conn->query($sql);

	if ($result->num_rows > 0) 
	{
		// output data of each row
		while($row = $result->fetch_assoc()) {
			
			$password = randomPassword();
			$emailId = $row['emailId'];
			$userName = $row['userName'];
			$userId = $row['userId'];

			sendMail($emailId,$password,$userName);
			$updatePassword = "UPDATE `user` SET `password`='$password' WHERE userId = $userId";
			if ($conn->query($updatePassword) === TRUE) 
			{
				echo "Success";
			}
			else
			{
				echo "Failure";
			}
		}
	} 
	else {
		echo "Invalid email";
	}
?>