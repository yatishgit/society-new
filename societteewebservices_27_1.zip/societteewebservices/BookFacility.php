<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$bookingDate = null;
$userId = null;
$facilityId = null;
$fromDate = null;
$toDate = null;
$buildingId = null;
$flatNo = null;
$amountDeposited = null;
$depositedDate = null;
$rdescription = null;
$rpaymentMode =null;
$rchequeNo =null;
$paymentMode = null;
$chequeNo = null;
$societyId = null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$bookingDate = $_POST['bookingDate'];
	$userId = $_POST['userId'];
	$facilityId = $_POST['facilityId'];
	$fromDate = $_POST['fromDate'];
	$toDate = $_POST['toDate'];
	$buildingId = $_POST['buildingId'];
	$flatNo = $_POST['flatNo'];
	$amountDeposited = $_POST['amountDeposited'];
	$depositedDate = $_POST['depositedDate'];
	$rdescription = $_POST['rdescription'];
	$rpaymentMode = $_POST['rpaymentMode'];
	$rchequeNo = $_POST['rchequeNo'];
	$paymentMode = $_POST['paymentMode'];
	$chequeNo = $_POST['chequeNo'];
	$societyId = $_POST['societyId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$bookingDate = $_GET['bookingDate'];
	$userId = $_GET['userId'];
	$facilityId = $_GET['facilityId'];
	$fromDate = $_GET['fromDate'];
	$toDate = $_GET['toDate'];
	$buildingId = $_GET['buildingId'];
	$flatNo = $_GET['flatNo'];
	$amountDeposited = $_GET['amountDeposited'];
	$depositedDate = $_GET['depositedDate'];
	$rdescription = $_GET['rdescription'];
	$rpaymentMode = $_GET['rpaymentMode'];
	$rchequeNo = $_GET['rchequeNo'];
	$paymentMode = $_GET['paymentMode'];
	$chequeNo = $_GET['chequeNo'];
	$societyId = $_GET['societyId'];
}
$d=date('Y-m-d H:i:s');

$bookFacility = "INSERT INTO `booking`(`bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, 
				`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `paymentMode`, `chequeNo`, 
				`currentDate`, `societyId`)
				VALUES 
				('$bookingDate',$userId,$facilityId,'$fromDate','$toDate',$buildingId,'$flatNo',$amountDeposited,'$depositedDate','$rdescription','$rpaymentMode',
				'$rchequeNo','$paymentMode','$chequeNo','$d',$societyId)";

	if ($conn->query($bookFacility) === TRUE) 
	{
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>