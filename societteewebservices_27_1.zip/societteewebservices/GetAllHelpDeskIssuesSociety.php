<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;


if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];
//$societyId = 10;

$issues = array();
$sql = "SELECT `issueId`, `societyId`, `issueName`, `buildingId`, `category`, `userId`, `description`, `issueDate`, `resolvedStatus`, `resolvedDate`, 
		`status`, `image`, `issueBy`, `currentDate`, `type`
		FROM `helpdesksociety` 
		WHERE societyId=$societyId";
		
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		//echo var_dump($result);
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$issues[]=array("issueId" => $row['issueId'],
							 "issueName" => $row['issueName'],
							 "buildingId" =>$row['buildingId'],
							 "category" =>$row['category'],
							 "description" => $row['description'],
							 "userId" => $row['userId'],
							 "issueDate" => $row['issueDate'],
							 "societyId" => $row['societyId'],
							 "resolvedStatus" => $row['resolvedStatus'],
							 "resolvedDate" => $row['resolvedDate'],
							 "status" => $row['status'],
							 "image" => $row['image'],
							 "issueBy" => $row['issueBy'],
							 "currentDate" => $row['currentDate'],
							 "type" => $row['type']);
		}
		$response = array("response" => $issues);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}

?>