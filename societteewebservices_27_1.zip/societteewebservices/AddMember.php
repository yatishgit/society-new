<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$userDetails = array();

$name = null;
$societyId = null;
$emailId = null;
$buildingId = null;
$image = null;
$contactNo = null;
$userType = null;
$flatNo = null;
$expiryDate = null;
$pollingAllowed = null;
$userName = null;
$password = null;


if($_SERVER['REQUEST_METHOD']=='POST'){
	$name = $_POST['name'];
	$societyId = $_POST['societyId'];
	$emailId = $_POST['emailId'];
	$buildingId = $_POST['buildingId'];
	$image = $_POST['image'];
	$contactNo = $_POST['contactNo'];
	$userType = $_POST['userType'];
	$flatNo = $_POST['flatNo'];
	$expiryDate = $_POST['expiryDate'];
	$pollingAllowed = $_POST['pollingAllowed'];
	$userName = $_POST['userName'];
	$password = $_POST['password'];
}
if($_SERVER['REQUEST_METHOD']=='GET'){
	$name = $_GET['name'];
	$societyId = $_GET['societyId'];
	$emailId = $_GET['emailId'];
	$buildingId = $_GET['buildingId'];
	$image = $_GET['image'];
	$contactNo = $_GET['contactNo'];
	$userType = $_GET['userType'];
	$flatNo = $_GET['flatNo'];
	$expiryDate = $_GET['expiryDate'];
	$pollingAllowed = $_GET['pollingAllowed'];
	$userName = $_GET['userName'];
	$password = $_GET['password'];
}
	 $sql = "INSERT INTO `user`(`image`, `name`, `userType`, `contactNo`, `emailId`, `expiryDate`, `approvalStatus`, `pollingAllowed`,
			`societyId`, `buildingId`, `flatNo`, `currentDate`, `viewFlagManager`, `viewFlagSadmin`, `username`, `password`, `valid`)
			VALUES ('$image','$name','$userType',$contactNo,'$emailId','$expiryDate',0,$pollingAllowed,$societyId,$buildingId,'$flatNo','NOW()',0,0,
			'$userName','$password',1)";
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result) {
		$response = array("response" => "success");
		echo json_encode($response);
	} 
	else {
		$response = array("response" => "failure");
		echo json_encode($response);
	}
	$conn->close();

?>