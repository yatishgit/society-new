<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buildingId = null;
$staffId=null;
$societyId =null;
$flatNo=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$buildingId=$_POST['buildingId'];
	$staffId = $_POST['staffId'];
	$societyId = $_POST['societyId'];
	$flatNo = $_POST['flatNo'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$buildingId=$_GET['buildingId'];
	$staffId = $_GET['staffId'];
	$societyId = $_GET['societyId'];
	$flatNo = $_GET['flatNo'];
}
//SELECT `staffId`, `name`, `designation`, `contactNo`, `idProof`, `societyId`, `buildingId`, `
//`, `currentDate` FROM `staff` WHERE 1

$deleteStaff="DELETE 
				FROM `staff` 
				WHERE staffId=$staffId and societyId=$societyId and buildingId=$buildingId and flatNo='$flatNo'";
				
	if ($conn->query($deleteStaff) === TRUE) 
	{
		//$sql="SELECT * FROM `visitor` WHERE buildingId=$buildingId and buildingId=$visitorId and societyId=$societyId and flatNo='$flatNo'";
		$response = array("response" => "success");
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>