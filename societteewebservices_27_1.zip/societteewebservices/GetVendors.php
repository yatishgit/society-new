<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$buzz = array();
$buzz_details = array();
if($_SERVER['REQUEST_METHOD']=='POST')
	$societyId=$_POST['societyId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$societyId=$_GET['societyId'];
//$societyId = 8;

$categoryId=null;

	//fetching distinct categories from buzz
	$sql = "SELECT distinct(`categoryId`) `categoryId`
			FROM `vendor` 
			WHERE 1";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$categoryId = $row['categoryId'];
			//echo $category_id;
			//fetching vendor details
			$categorysql = "SELECT `vendorId`, `categoryId`, `vendorName`, `company`, `description`, `contact1`, `contact2`, `vendorAdd1`, 
							`vendorAdd2`, `vendorAdd3`, `idProof`, `currentDate`, `dummyfield2`, `societyId` 
							FROM `vendor` 
							WHERE `societyId`= $societyId and categoryId=$categoryId";
							
			$result1 = $conn->query($categorysql);

			if ($result1->num_rows > 0) {
				// output data of each row
				$buzz = null;
				while($row1 = $result1->fetch_assoc()) {
					$buzz[] = array("categoryId" => $row1['categoryId'],
									"societyId" => $row1['societyId'],
									"vendorName" => $row1['vendorName'],
									"vendorId" => $row1['vendorId'],
									"contact1" => $row1['contact1'],
									"contact2" => $row1['contact2'],
									"vendorAdd1" => $row1['vendorAdd1'],
									"vendorAdd2" => $row1['vendorAdd2'],
									"vendorAdd3" => $row1['vendorAdd3'],
									"company" => $row1['company'],
									"idProof" => $row1['idProof'],
									"description" => $row1['description'],
									"currentDate" => $row1['currentDate'],
									"dummyfield2" => $row1['dummyfield2']);	
				}
			}
					
			$getcategory = "SELECT `categoryId`,`categoryName`, `image`, `description`, `currentDate` FROM `category` WHERE `categoryId`=$categoryId";
			$result11 = $conn->query($getcategory);

			if ($result11->num_rows > 0) {
						// output data of each row
				while($row = $result11->fetch_assoc()) {
					$buzz_details[] = array("category_id" => $row['categoryId'],
													"categoryName" => $row['categoryName'],
													"description" => $row['description'],
													"image" => $row['image'],
													"currentDate" => $row['currentDate'],
													"vendors" => $buzz);
				}	
			}		
				
		}
		$response = array("response" => $buzz_details);
		echo json_encode($response);
				
	}
	else 
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}
?>
