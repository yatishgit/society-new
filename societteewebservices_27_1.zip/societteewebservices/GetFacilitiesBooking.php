<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$facilityId = null;
$fromDate=null;
$toDate=null;
$buildingId=null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
	$facilityId=$_POST['facilityId'];
	$fromDate=$_POST['fromDate'];
	$fromDate=$fromDate.' 23:59:59';
	$toDate=$_POST['toDate'];
	$toDate=$toDate.' 23:59:59';
	$buildingId=$_POST['buildingId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$facilityId=$_GET['facilityId'];
	$fromDate=$_GET['fromDate'];
	$toDate=$_GET['toDate'];
	$buildingId=$_GET['buildingId'];
}

//SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, 
//`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`,
// `chequeNo`, `currentDate`, `status`, `societyId` FROM `booking` WHERE 1

$selectBooking="SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`,
				`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`,
				`chequeNo`, `currentDate`, `status`, `societyId` 
				FROM `booking` 
				WHERE facilityId=$facilityId and fromDate >= '$fromDate' and toDate <= '$toDate' and buildingId=$buildingId";
				
$result=$conn->query($selectBooking);
$booking=array();
	if ($result->num_rows > 0) 
	{
		while($row = $result->fetch_assoc()) 
		{
			$booking[]=array("bookingId" => $row['bookingId'],
							 "bookingDate" => $row['bookingDate'],
							 "userId" => $row['userId'],
							 "facilityId" => $row['facilityId'],
							 "fromDate" => $row['fromDate'],
							 "toDate" => $row['toDate'],
							 "buildingId" => $row['buildingId'],
							 "flatNo" => $row['flatNo'],
							 "description" => $row['description'],
							 "status" => $row['status']);
		}
		$response = array("response" => $booking);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}

?>