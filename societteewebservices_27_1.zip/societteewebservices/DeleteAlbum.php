<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$societyId = null;
$albumId=null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
	$societyId=$_POST['societyId'];
	$albumId = $_POST['albumId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$societyId=$_GET['societyId'];
	$albumId = $_GET['albumId'];
}

//$societyId = 8;DELETE FROM `albumimages` WHERE `imageId`=245 and `albumId`='11111526816' and `societyId`=8 
//SELECT * FROM `albumimages` WHERE `imageId`= 245 and `albumId`='11111526816' and `societyId`= 8

$deleteAlbum = "DELETE 
				FROM `album` 
				WHERE societyId=$societyId and albumId=$albumId";
				
$deleteAlbumImages = "DELETE FROM `albumimages` 
					  WHERE societyId=$societyId and albumId=$albumId";
	if ($conn->query($deleteAlbumImages)===TRUE) 
	{
		$sql="SELECT * FROM `albumimages` WHERE `albumId`=$albumId and `societyId`= $societyId";
		$result = $conn->query($sql);
		if($result->num_rows <=0)
		{
			if($conn->query($deleteAlbum) === TRUE)
			{
				$sql="SELECT * FROM `album` WHERE `albumId`=$albumId and `societyId`= $societyId";
				$result = $conn->query($sql);
				if($result->num_rows <=0)
				{
					$response = array("response" => "success");
					echo json_encode($response);
				}
				else
				{
					$response = array("response" => "failure");
					echo json_encode($response);
				}				
				
			}
			else
			{
				$response = array("response" => "failure");
				echo json_encode($response);
			}
		}
		else
		{
			$response = array("response" => "failure");
			echo json_encode($response);
		}
		
	}
	else
	{
		$response = array("response" => "failure");
			echo json_encode($response);
	}
	
	
?>