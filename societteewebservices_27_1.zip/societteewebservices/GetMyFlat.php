<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$userId = null;
if($_SERVER['REQUEST_METHOD']=='POST')
	$userId=$_POST['userId'];
if($_SERVER['REQUEST_METHOD']=='GET')
	$userId=$_GET['userId'];

$flatNo = null;
$countMember = 0; 
$countVehicles = 0;
$countBooking = 0;
$countStaff = 0;
$countVisitors = 0;
$countTransaction = 0;
$memberDetails = array();
$vehicleDetails = array();
$bookingDetails = array();
$staffDetails = array();
$visitorDetails = array();
$myFlat=array();
//SELECT `userId`, `image`, `name`, `userType`, `contactNo`, `emailId`, `expiryDate`, `approvalStatus`, `pollingAllowed`, `societyId`,
// `buildingId`, `flatNo`, `currentDate`, `viewFlagManager`, `viewFlagSadmin`, `username`, `password`, `valid` FROM `user` WHERE 1

$sql = "SELECT `userId`, `name`, `emailId`, `image`, `societyId`, `buildingId`, `contactNo`, `userType`, `flatNo`, `approvalStatus`, 
		`expiryDate`, `pollingAllowed`, `userName`, `password`, `currentDate`
		FROM `user` 
		WHERE userId = $userId";
$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// fetching user details
		while($row = $result->fetch_assoc()) {
		
				$flatNo1 = $row['flatNo'];
				
				$flat = split ("\,", $flatNo1);
				
				for($i=0;$i<sizeOf($flat);$i++)
				{
					$flatNo = $flat[$i];
				
				
				//fetch flat member details starts
				$getMembers = "SELECT `userId`, `name`, `emailId`, `image`, `societyId`, `buildingId`, `contactNo`, `userType`, `flatNo`, `approvalStatus`, 
								`expiryDate`, `pollingAllowed`, `userName`, `password`, `currentDate` 
								FROM `user` 
								WHERE flatNo = $flatNo";
				$memberResult = $conn -> query($getMembers);
				if($memberResult -> num_rows >0)
				{
					while($memRow = $memberResult -> fetch_assoc())
					{
						$memberDetails[] = array("userId" => $memRow['userId'],
												 "name" => $memRow['name'],
												 "emailId" => $memRow['emailId'],
												 "image" => $memRow['image'],
												 "contactNo" => $memRow['contactNo'],
												 "userType" => $memRow['userType']);
						$countMember = $countMember+1;
					}
				}
				//fetch flat member details ends
				
				//SELECT `parkingId`, `societyId`, `buildingId`, `flatNo`, `parkingSlot`, `vehicleNo`, `vehicleType`, `currentDate` FROM `parking` WHERE 1
				//fectch vehicles details start
				$getVehicles = "SELECT `parkingId`, `societyId`, `buildingId`, `flatNo`, `parkingSlot`, `vehicleNo`, `vehicleType`, `currentDate` 
								FROM `parking` 
								WHERE flatNo=$flatNo";
				$vehicleResult = $conn -> query($getVehicles);
				if($vehicleResult -> num_rows >0)
				{
					while($vRow = $vehicleResult -> fetch_assoc())
					{
						$vehicleDetails[] = array("parkingId" => $vRow['parkingId'],
												 "parkingSlot" => $vRow['parkingSlot'],
												 "vehicleNo" => $vRow['vehicleNo'],
												 "vehicleType" => $vRow['vehicleType']);
						$countVehicles = $countVehicles+1;
					}
				}
				//fectch vehicles details ends	

				//SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, 
				//`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`, 
				//`chequeNo`, `currentDate`, `status`, `societyId`, `viewFlagManager`, `viewFlagSadmin` FROM `booking` WHERE 1
				//fetch booking details starts
				$getBooking = "SELECT `bookingId`, `bookingDate`, `userId`, `facilityId`, `fromDate`, `toDate`, `buildingId`, `flatNo`, `amountDeposited`, 
								`depositedDate`, `rdescription`, `rpaymentMode`, `rchequeNo`, `amountRefunded`, `refundedDate`, `description`, `paymentMode`,
								`chequeNo`, `currentDate`, `status`, `societyId` 
								FROM `booking` 
								WHERE flatNo = $flatNo";
				$bookingResult = $conn -> query($getBooking);
				if($bookingResult -> num_rows >0)
				{
					while($bRow = $bookingResult -> fetch_assoc())
					{
						$bookingDetails[] = array("bookingId" => $bRow['bookingId'],
												 "bookingDate" => $bRow['bookingDate'],
												 "userId" => $bRow['userId'],
												 "facilityId" => $bRow['facilityId'],
												 "fromDate" => $bRow['fromDate'],
												 "toDate" => $bRow['toDate'],
												 "amountDeposited" => $bRow['amountDeposited'],
												 "depositedDate" => $bRow['depositedDate'],
												 "rdescription" => $bRow['rdescription'],
												 "rpaymentMode" => $bRow['rpaymentMode'],
												 "rchequeNo" => $bRow['rchequeNo'],
												 "amountRefunded" => $bRow['amountRefunded'],
												 "refundedDate" => $bRow['refundedDate'],
												 "description" => $bRow['description'],
												 "paymentMode" => $bRow['paymentMode'],
												 "chequeNo" => $bRow['chequeNo'],
												 "status" => $bRow['status']);
						$countBooking = $countBooking+1;
					}
				}
				//fetch booking details ends
				
				//SELECT `staffId`, `name`, `designation`, `contactNo`, `idProof`, `societyId`, `buildingId`, `flatNo`, `currentDate` FROM `staff` WHERE 1
				//fetch staff details start
				$getStaff = "SELECT `staffId`, `name`, `designation`, `contactNo`, `idProof`, `societyId`, `buildingId`, `flatNo`, `currentDate` 
								FROM `staff`
								WHERE flatNo = $flatNo";
				$staffResult = $conn -> query($getStaff);
				if($staffResult -> num_rows >0)
				{
					while($sRow = $staffResult -> fetch_assoc())
					{
						$staffDetails[] = array("staffId" => $sRow['staffId'],
												 "name" => $sRow['name'],
												 "designation" => $sRow['designation'],
												 "contactNo" => $sRow['contactNo'],
												 "idProof" => $sRow['idProof']);
						$countStaff = $countStaff+1;
					}
				}
				//fetch staff details ends
				//SELECT `visitorId`, `name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, `currentDate`, `checkinTime`, 
				//`checkoutTime`, `expectedTime`, `date` FROM `visitor` WHERE 1
				//fetch visitor details starts
				$getVisitors = "SELECT `visitorId`, `name`, `contactNo`, `societyId`, `buildingId`, `flatNo`, `visitorType`, `currentDate`, `checkinTime`,
								`checkoutTime`, `expectedTime`, `date` 
								FROM `visitor` 
								WHERE  flatNo = $flatNo";
				$visitorResult = $conn -> query($getVisitors);
				if($visitorResult -> num_rows >0)
				{
					while($visRow = $visitorResult -> fetch_assoc())
					{
						$visitorDetails[] = array("visitorId" => $visRow['visitorId'],
												 "name" => $visRow['name'],
												 "contactNo" => $visRow['contactNo'],
												 "visitorType" => $visRow['visitorType'],
												 "checkinTime" => $visRow['checkinTime'],
												 "checkoutTime" => $visRow['checkoutTime'],
												 "expectedTime" => $visRow['expectedTime'],
												 "date" => $visRow['date']);
						$countVisitors = $countVisitors+1;
					}
				}				
				//fetch visitor details starts
			
				
				//fetch tarnsaction details starts
				$getTransations = "SELECT count(*) as 'countTransactions'
								FROM `payment` 
								WHERE flatNo = $flatNo";
				$transactionResult = $conn -> query($getTransations);
				if($transactionResult -> num_rows >0)
				{
					while($tRow = $transactionResult -> fetch_assoc())
					{
						$countTransaction = $tRow['countTransactions'];
					}
				}
				//fetch transaction details ends
				$myFlat[] = array("flatNo" => $flatNo,
						"countMember" => $countMember,
						"memberDetails" => $memberDetails,
						"countVehicles" => $countVehicles,
						"vehicleDetails" => $vehicleDetails,
						"countBooking" => $countBooking,
						"bookingDetails" => $bookingDetails,
						"countStaff" => $countStaff,
						"staffDetails" => $staffDetails,
						"countVisitors" => $countVisitors,
						"visitorDetails" => $visitorDetails,
						"countTransaction" => $countTransaction
						);
		}
			}
		
		$response = array("response" => $myFlat);
		echo json_encode($response);
	}
	else
	{
		$response = array("response" => "failure");
		echo json_encode($response);
	}
?>