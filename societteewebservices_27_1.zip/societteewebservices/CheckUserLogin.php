<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "societtee";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$userDetails = array();

$username = null;
$password = null;
$societyId = null;

if($_SERVER['REQUEST_METHOD']=='POST'){
	$json = json_decode(file_get_contents('php://input'), true);
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	$societyId = $_POST['societyId'];
}
if($_SERVER['REQUEST_METHOD']=='GET')
{
	$username = $_GET['username'];
	$password = $_GET['password'];
	$societyId = $_GET['societyId'];
}
	 
	 $sql = "SELECT `userId`, `name`, `emailId`, `image`, `societyId`, `buildingId`, `contactNo`, `userType`, `flatNo`, `approvalStatus`, 
			`expiryDate`, `pollingAllowed`, `userName`, `password`, `currentDate`
			FROM `user` 
			WHERE userName='$username' and password='$password' and societyId='$societyId'";
	
	
	$result = $conn->query($sql);
	//echo var_dump($result);
	if ($result->num_rows>0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {	
		
		$buildingName=null;
		$buildingId=$row['buildingId'];
		$societyName = null;
		
		$sqlb = "SELECT `buildingId`, `buildingName`, `description`, `societyId`, `dummyfield`, `currentDate` 
				FROM `building` 
				WHERE societyId='$societyId' and buildingId=$buildingId";
	
	
		$resultb = $conn->query($sqlb);
		//echo var_dump($result);
		if ($resultb->num_rows>0) {
			// output data of each row
			while($rowb = $resultb->fetch_assoc()) {
				
				$buildingName=$rowb['buildingName'];
			}
		}
		
		
		$sqlss = "SELECT `societyId`, `regiNo`, `societyName`, `managerUsername`, `societyAdd1`, `societyAdd2`, `societyAdd3`, `societyAdd4`,
				`currentDate`, `valid` 
				FROM `society` 
				WHERE  societyId='$societyId'";
	
	
		$resultss = $conn->query($sqlss);
		//echo var_dump($result);
		if ($resultss->num_rows>0) {
			// output data of each row
			while($rowss = $resultss->fetch_assoc()) {
				
				$societyName=$rowss['societyName'];
			}
		}
			
		
			
			$flat= $row['flatNo'];
			
			$flats=split ("\,", $flat);
				
			$userDetails = array("emailId" => $row['emailId'],
								 "name" => $row['name'],
								 "contactNo" => $row['contactNo'],
								 "userId" => $row['userId'],
								 "userType" => $row['userType'],
								 "userName" => $row['userName'],
								 "password" => $row['password'],
								 "societyId" => $row['societyId'],
								 "buildingId" => $row['buildingId'],
								 "buildingName" => $buildingName,
								 "flatNos" => $flats,
								 "approvalStatus" => $row['approvalStatus'],
								 "expiryDate" => $row['expiryDate'],
								 "pollingAllowed" => $row['pollingAllowed'],
								 "societyName" => $societyName);
		}
		$res = array("response" => $userDetails);
		echo json_encode($res);
	} 
	else {
		$res = array("response" => "failure");
		echo json_encode($res);
	}
	

?>